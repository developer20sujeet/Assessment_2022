class Solution {
    public boolean divisorGame(int N) {
        return N % 2 == 0;
    }
}
